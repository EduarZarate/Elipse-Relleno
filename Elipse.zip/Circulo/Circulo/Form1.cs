﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Elipse
{
    public partial class Form1 : Form
    {
        private Graphics vector;
        private int[] cx = new int[10000];
        private int[] cy = new int[10000];
        private int z = 1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "50"; // Valor predeterminado para a
            textBox4.Text = "30"; // Valor predeterminado para b
            textBox5.Text = "Pk\t-\tX\t-\tY \r\n";
            textBox6.Text = "Y \t - \t X  \r\n";
            textBox7.Text = "X \t - \t -Y  \r\n";
            textBox8.Text = "-Y \t - \t X  \r\n";
            textBox9.Text = "-X \t - \t -Y  \r\n\n";
            textBox10.Text = "-Y \t - \t -X  \r\n";
            textBox11.Text = "-X \t - \t Y  \r\n\n";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int xc, yc, a, b;

            xc = Convert.ToInt32(textBox1.Text);
            yc = Convert.ToInt32(textBox2.Text);
            if (!int.TryParse(textBox3.Text, out a) || !int.TryParse(textBox4.Text, out b))
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos para a y b.");
                return;
            }
            Elipse(a, b);
            Dibujar(xc, yc);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int xc, yc;
            xc = Convert.ToInt32(textBox1.Text);
            yc = Convert.ToInt32(textBox2.Text);
            vector = pictureBox1.CreateGraphics();
            int xcentro = pictureBox1.Width / 2;
            int ycentro = pictureBox1.Height / 2;
            vector.TranslateTransform(xcentro, ycentro);
            vector.ScaleTransform(1, -1);
            Pen lapiz2 = new Pen(Color.Yellow);
            for (int i = 1; i < z; i++)
            {
                vector.DrawLine(lapiz2, xc, yc, (cx[i] + xc), (cy[i] + yc));
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            vector = pictureBox1.CreateGraphics();
            int xcentro = pictureBox1.Width / 2;
            int ycentro = pictureBox1.Height / 2;
            Pen lapiz = new Pen(Color.Black, 2);
            vector.TranslateTransform(xcentro, ycentro);
            vector.ScaleTransform(1, -1);
            vector.DrawLine(lapiz, xcentro * -1, 0, xcentro * 2, 0);
            vector.DrawLine(lapiz, 0, ycentro, 0, ycentro * -1);

            for (int i = -xcentro; i < xcentro; i += 10)
            {
                vector.DrawLine(lapiz, 5, i, -5, i); //division de las y
                vector.DrawLine(lapiz, i, 5, i, -5); //division de las x
            }
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "50"; // Restaurar valor predeterminado para a
            textBox4.Text = "30"; // Restaurar valor predeterminado para b
            textBox5.Text = "Pk\t-\tX\t-\tY \r\n";
            textBox6.Text = "Y \t - \t X  \r\n";
            textBox7.Text = "X \t - \t -Y  \r\n";
            textBox8.Text = "-Y \t - \t X  \r\n";
            textBox9.Text = "-X \t - \t -Y  \r\n\n";
            textBox10.Text = "-Y \t - \t -X  \r\n";
            textBox11.Text = "-X \t - \t Y  \r\n\n";
            z = 1;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            int xcentro = pictureBox1.Width / 2;
            int ycentro = pictureBox1.Height / 2;
            Pen lapiz = new Pen(Color.Black, 2);
            e.Graphics.TranslateTransform(xcentro, ycentro); //convierte las coordenadas a la forma de la grafica
            e.Graphics.ScaleTransform(1, -1); //se convierten a coordenadas normales

            e.Graphics.DrawLine(lapiz, xcentro * -1, 0, xcentro * 2, 0);
            e.Graphics.DrawLine(lapiz, 0, ycentro, 0, ycentro * -1);
            using (Font myFont = new Font("Arial", 14))
            {
                for (int i = -xcentro; i < xcentro; i += 10)
                {
                    e.Graphics.DrawLine(lapiz, 5, i, -5, i); //division de las y
                    e.Graphics.DrawLine(lapiz, i, 5, i, -5); //division de las x
                }

                int j = -300, k = 250, m = 18;
                for (int l = 50; l < 960; l += 50)
                {
                    using (Font font = new Font("Times New Roman", 10, FontStyle.Bold, GraphicsUnit.Pixel))
                    {
                        Point point1 = new Point(l - 10, ycentro + 10);
                        if (j != 0)
                        {
                            TextRenderer.DrawText(e.Graphics, Convert.ToString(j), font, point1, Color.Red);
                        }
                        Point point2 = new Point(xcentro + 10, m);
                        if (k != 0)
                        {
                            TextRenderer.DrawText(e.Graphics, Convert.ToString(k), font, point2, Color.Red);
                        }
                    }

                    j += 50;
                    k -= 50;
                    m += 50;
                }
            }
        }

        private void Elipse(int a, int b)
        {
            int X, Y;
            double d1, d2;
            X = 0;
            Y = b;
            d1 = (b * b) - (a * a * b) + (0.25 * a * a);
            while ((a * a * (Y - 0.5)) > (b * b * (X + 1)))
            {
                if (d1 < 0)
                {
                    d1 += (b * b * ((2 * X) + 3));
                }
                else
                {
                    d1 += (b * b * ((2 * X) + 3)) + (a * a * ((-2 * Y) + 2));
                    Y--;
                }
                X++;
                cx[z] = X;
                cy[z] = Y;
                textBox5.Text += "" + (X) + "\t-\t" + (Y) + " \r\n";
                z++;
            }
            d2 = ((b * b) * ((X + 0.5) * (X + 0.5))) + ((a * a) * ((Y - 1) * (Y - 1))) - (a * a * b * b);
            while (Y > 0)
            {
                if (d2 < 0)
                {
                    d2 += (b * b * ((2 * X) + 2)) + (a * a * ((-2 * Y) + 3));
                    X++;
                }
                else
                {
                    d2 += (a * a * ((-2 * Y) + 3));
                }
                Y--;
                cx[z] = X;
                cy[z] = Y;
                textBox5.Text += "" + (X) + "\t-\t" + (Y) + " \r\n";
                z++;
            }
        }

        private void Dibujar(int x, int y)
        {
            int xc, yc, a, b;

            xc = Convert.ToInt32(textBox1.Text);
            yc = Convert.ToInt32(textBox2.Text);
            if (!int.TryParse(textBox3.Text, out a) || !int.TryParse(textBox4.Text, out b))
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos para a y b.");
                return;
            }
            vector = pictureBox1.CreateGraphics();
            int xcentro = pictureBox1.Width / 2;
            int ycentro = pictureBox1.Height / 2;
            Pen lapiz = new Pen(Color.Red, 2);
            vector.TranslateTransform(xcentro, ycentro);
            vector.ScaleTransform(1, -1);
            for (int i = 1; i < z; i++)
            {
                vector.DrawEllipse(lapiz, (cx[i] + xc), (cy[i] + yc), a, b); // Cambiado DrawRectangle por DrawEllipse
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged_1(object sender, EventArgs e)
        {
            int a;
            if (int.TryParse(textBox13.Text, out a))
            {
                // Actualizar el ancho del elipse
                // Puedes poner aquí la lógica para actualizar el ancho del elipse
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un valor numérico válido para RX.");
            }
        }

        private void textBox12_TextChanged_1(object sender, EventArgs e)
        {
            int b;
            if (int.TryParse(textBox12.Text, out b))
            {
                // Actualizar la altura del elipse
                // Puedes poner aquí la lógica para actualizar la altura del elipse
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un valor numérico válido para RY.");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
