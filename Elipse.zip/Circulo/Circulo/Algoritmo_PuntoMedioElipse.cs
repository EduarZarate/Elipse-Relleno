﻿namespace Elipse
{
    internal class Algoritmo_PuntoMedioElipse
    {
    }
}